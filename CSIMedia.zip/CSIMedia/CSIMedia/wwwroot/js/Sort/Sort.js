﻿var sortObject = {

    AddRowToTable: function () {
        var sortVal = $("#txtSortVal").val();

        if (sortVal) {
            if ((sortVal != '') && ($.isNumeric(sortVal))) {
                var index = $("#tblSortValues tbody tr").length + 1;

                var markup = "<tr><td>" + index + "</td><td>" + sortVal + "</td></tr>";

                $("#tblSortValues tbody").append(markup);

                $("#txtSortVal").val('');
            }
        }
        else {
            return;
        }     
    },

    ClearTable: function () {
        $("#tblSortValues tbody tr").remove();
    },

    GenerateList: function () {
        var tableRows = $("#tblSortValues tbody tr");
        var sortList = "";

        for (var i = 0; i < tableRows.length; i++) {
            var sortVal = $(tableRows[i]).find("td")[1].innerText;

            sortList = (i == 0) ? sortVal : sortList + "," + sortVal;
        }

        sortList = sortList.trim(",");

        $("#hidSortValues").val(sortList);

        sortObject.FormSubmit();
    },

    FormSubmit: function () {
        $("#frmSort").submit();
    }
}

$(document).ready(function() {
    $("#btnAdd").on("click", function () {
        sortObject.AddRowToTable();
    });

    $("#btnClear").on("click", function () {
        sortObject.ClearTable();
    });

    $("#btnSort").on("click", function () {
        sortObject.GenerateList();
    });
});