﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using CSIMediaTest.Models;
using CSIMediaTest.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace CSIMediaTest.Controllers.Web
{
    public class SortController : Controller
    {
        //Working at home using the free version of visual studio, so I have had to go back to old style
        //of database connection as I am using .net core and had problems using entity framework
        private string _conn = @"Data Source=DESKTOP-IPPVKT1\SQLEXPRESS;Initial Catalog=CSIMedia;Integrated Security=True;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        private CSIMediaContext _context;

        public SortController(CSIMediaContext context)
        {
            _context = context;
        }

        public IActionResult Sort(List<int> model)
        {
            return View("Sort", model);
        }

        [HttpPost]
        public IActionResult Sort(string sortValues, string sortOrder)
        {
            var timeStarted = DateTime.Now;

            //The data has been passed as csv and then split here an List<int>
            //created.  Could have possibly passed it over as JSON, but that could 
            //be done another day.
            var sortList = sortValues.Split(',').Select(int.Parse).ToList();

            var sortedList = new List<int>();

            //There is a bit too much going on in this controller action
            //and things could be tidied up if I had time.
            if (sortOrder.ToLower() == "ascending")
            {
                sortedList = sortList.OrderBy(x => x).ToList();
            }
            else
            {
                sortedList = sortList.OrderByDescending(x => x).ToList();
            }

            string sortedCsv = String.Join(",", sortedList.Select(x => x.ToString()).ToArray());

            var timeFinished = DateTime.Now;

            _context.Add(new SortedInt()
            {
                SortedData = sortedCsv,
                UnsortedData = sortValues,
                CreatedDate = DateTime.Now,
                SortMethod = sortOrder.ToLower(),
                TimeTakenToSort = (int)Math.Round(timeFinished.Subtract(timeStarted).TotalMilliseconds)
            });

            _context.SaveChanges();
      
            return View("Sort", sortedList);
        }

        public IActionResult SortList()
        {
            //The database stuff could have been refactored and placed in a separate 
            //class.  The context could have been passed in through the constructor, 
            //but I was short of time
            var sortList = _context.SortedInt
                                .Select(x => new SortedIntViewModel()
                                {
                                    SortedIntID = x.SortedIntID,
                                    CreatedDate = x.CreatedDate,
                                    SortedData = x.SortedData,
                                    UnsortedData = x.UnsortedData,
                                    SortMethod = x.SortMethod,
                                    TimeTakenToSort = x.TimeTakenToSort
                                })
                                .ToList();

            return View("SortList", sortList);
        }

        public IActionResult ExportSortListAsML()
        {
            //The database stuff could have been refactored and placed in a separate 
            //class.  The context could have been passed in through the constructor, 
            //but I was short of time
            var sortList = _context.SortedInt
                               .Select(x => new SortedIntViewModel()
                               {
                                   SortedIntID = x.SortedIntID,
                                   CreatedDate = x.CreatedDate,
                                   SortedData = x.SortedData,
                                   UnsortedData = x.UnsortedData,
                                   SortMethod = x.SortMethod,
                                   TimeTakenToSort = x.TimeTakenToSort
                               })
                               .ToList();

            var sortXML = "<?xml version=\"1.0\" encoding =\"UTF-8\" ?>";


            //using (var sw = new StringWriter())
            //{
            //using (var writer = new XmlWriter.Create())
            //{
            //    writer.WriteStartElement("sortlist");

            //    foreach (var item in sortList)
            //    {
            //        writer.WriteStartElement("sortitem");
            //        writer.WriteElementString("id", item.SortedIntID.ToString());
            //        writer.WriteElementString("unsorteddata", item.UnsortedData);
            //        writer.WriteElementString("sorteddata", item.SortedData);
            //        writer.WriteElementString("createddate", item.CreatedDate.ToShortDateString());
            //        writer.WriteElementString("timetakentosort", item.TimeTakenToSort.ToString());
            //        writer.WriteEndElement();
            //    }

            //    writer.WriteEndElement();

            //    writer.Flush();
            //}

            //    sortXML = sw.ToString();
            //}

            //I had to brute force this bit as I am using .NET Core
            //and the code above would not work
            sortXML += "<sortlist>";

            foreach (var item in sortList)
            {
                sortXML += "<sortitem>";
                sortXML += "<id>" + item.SortedIntID.ToString() + "</id>";
                sortXML += "<unsorteddata>" + item.UnsortedData + "</unsorteddata>";
                sortXML += "<sorteddata" + item.SortedData + "</sorteddata>";
                sortXML += "<sortmethod" + item.SortMethod + "</sortmethod>";
                sortXML += "<createddate" + item.CreatedDate.ToShortDateString() + "</createddate>";
                sortXML += "<timetakentosort" + item.TimeTakenToSort.ToString() + "</timetakentosort>";
                sortXML += "</sortitem>";
            }

            sortXML += "</sortlist>";

            return File(Encoding.UTF8.GetBytes(sortXML),
                    "text/plain",
                     string.Format("SortList.xml"));
        }
    }
}
