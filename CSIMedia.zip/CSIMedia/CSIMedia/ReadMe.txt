﻿The database will reside in the localdb which can be viewed from SQL Server Object Explorer

Run the CreateDatabase.sql in SQL Server Object Explorer, it resides in scripts
Then run CreateTable.sql

There is only one table in the database

The database connection string is placed in config.json

The Home, Contact and About screens are there for visuals

The Sort screen will allow the sorting and saving of data.  The Sort List screen 
shows the saved data and allows export as xml