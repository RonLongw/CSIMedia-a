﻿USE [CSIMedia]
GO

/****** Object:  Table [dbo].[SortedInt]    Script Date: 07/06/2017 15:45:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[SortedInt](
	[SortedIntID] [int] IDENTITY(1,1) NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[SortedData] [varchar](max) NOT NULL,
	[UnsortedData] [varchar](max) NOT NULL,
	[SortMethod] [varchar](20) NOT NULL,
	[TimeTakenToSort] [int] NOT NULL,
 CONSTRAINT [PK_SortedInts] PRIMARY KEY CLUSTERED 
(
	[SortedIntID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[SortedInt] ADD  CONSTRAINT [DF_SortedInts_CreatedDate]  DEFAULT (getdate()) FOR [CreatedDate]
GO


