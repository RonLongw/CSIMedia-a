﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CSIMediaTest.ViewModels
{
    public class SortedIntViewModel
    {
        public int SortedIntID { get; set; }
        public string SortedData { get; set; }
        public string UnsortedData { get; set; }
        public DateTime CreatedDate { get; set; }
        public string SortMethod { get; set; }
        public int TimeTakenToSort { get; set; }
    }
}
