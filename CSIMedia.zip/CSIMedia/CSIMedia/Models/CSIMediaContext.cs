﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace CSIMediaTest.Models
{
    /// <summary>
    /// CSIMediaContext is the database context and talks to the
    /// (localdb)MSSQLLocalDB which can be accessed via the SQL server Object Explorer
    /// </summary>
    public class CSIMediaContext : DbContext
    {
        private IConfigurationRoot _config;

        public CSIMediaContext(IConfigurationRoot config, DbContextOptions options) : base(options)
        {
            _config = config;
        }

        public DbSet<SortedInt> SortedInt { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);

            //The connect data is located in the config.json file
            optionsBuilder.UseSqlServer(_config["ConnectionStrings:CSIMediaContextConnection"]);
        }
    }
}
